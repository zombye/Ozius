# Zombye's original shaders

My original shader pack, with some small updates. Has no real name.
Some features are broken, and most of the pack is not very well optimized.

Requires a graphics card & drivers that supports GLSL 4.5 in an OpenGL 2.1 context.
